%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DIC INPUT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

DIC_DF = im2double(imread('U:\Projects\01_E3_modulation\2023-01-10_thal_vhl\02_edit\04_df\MED_2023-01-10_df1_w7DVU-DIC.tif'));
DIC_FF = im2double(imread('U:\Projects\01_E3_modulation\2023-04-13_DP9mut\02_edit\03_dic_ff\MED_2023-04-13_dic_ff1_DVU-DIC.tif'));
DIC_FF_red = imsubtract(DIC_FF, DIC_DF);
DIC_FF_red_avg = mean2(DIC_FF_red);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EPI INPUT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% epiDAPI_DF = im2double(imread(''));
% epiDAPI_FF = im2double(imread(''));
% epiDAPI_FF_red = imsubtract(epiDAPI_FF, epiDAPI_DF);
% epiDAPI_FF_red_avg = mean2(epiDAPI_FF_red);

epiGFP_DF = im2double(imread('U:\Projects\01_E3_modulation\2023-01-10_thal_vhl\02_edit\04_df\MED_2023-01-10_df1_w1DVU-EpiGFP.tif'));
epiGFP_FF = im2double(imread('U:\Projects\01_E3_modulation\2023-01-10_thal_vhl\02_edit\05_488_ff\MED_2023-01-10_4881_w1DVU-EpiGFP.tif'));
epiGFP_FF_red = imsubtract(epiGFP_FF, epiGFP_DF);
epiGFP_FF_red_avg = mean2(epiGFP_FF_red);

epiRFP_DF = im2double(imread('U:\Projects\01_E3_modulation\2023-01-10_thal_vhl\02_edit\04_df\MED_2023-01-10_df1_w2DVU-EpiRFP.tif'));
epiRFP_FF = im2double(imread('U:\Projects\01_E3_modulation\05_lab_journal\01_DVU\035_microinjection\2022-10-11_cullinstuff\02_eval\FFs\MED_ff5612_w1DVU-EpiRFP.tif'));
epiRFP_FF_red = imsubtract(epiRFP_FF, epiRFP_DF);
epiRFP_FF_red_avg = mean2(epiRFP_FF_red);

epiCY5_DF = im2double(imread('U:\Projects\01_E3_modulation\2023-01-10_thal_vhl\02_edit\04_df\MED_2023-01-10_df1_w3DVU-EpiCy5.tif'));
epiCY5_FF = im2double(imread('U:\Projects\01_E3_modulation\2023-01-10_thal_vhl\02_edit\06_640_ff\MED_2023-01-10_6401_w1DVU-EpiCy5.tif'));
epiCY5_FF_red = imsubtract(epiCY5_FF, epiCY5_DF);
epiCY5_FF_red_avg = mean2(epiCY5_FF_red);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CONFOCAL INPUT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% conf405_DF = im2double(imread(''));
% conf405_FF = im2double(imread(''));
% conf405_FF_red = imsubtract(conf405_FF, conf405_DF);
% conf405_FF_red_avg = mean2(conf405_FF_red);

conf488_DF = im2double(imread('U:\Projects\01_E3_modulation\2023-01-10_thal_vhl\02_edit\04_df\MED_2023-01-10_df1_w4DVU-Conf488.tif'));
conf488_FF = im2double(imread('U:\Projects\01_E3_modulation\2023-01-10_thal_vhl\02_edit\05_488_ff\MED_2023-01-10_4881_w2DVU-Conf488.tif'));
conf488_FF_red = imsubtract(conf488_FF, conf488_DF);
conf488_FF_red_avg = mean2(conf488_FF_red);

conf561_DF = im2double(imread('U:\Projects\01_E3_modulation\2023-01-10_thal_vhl\02_edit\04_df\MED_2023-01-10_df1_w5DVU-Conf561.tif'));
conf561_FF = im2double(imread('U:\Projects\01_E3_modulation\05_lab_journal\01_DVU\035_microinjection\2022-10-11_cullinstuff\02_eval\FFs\MED_ff5612_w2DVU-Conf561.tif'));
conf561_FF_red = imsubtract(conf561_FF, conf561_DF);
conf561_FF_red_avg = mean2(conf561_FF_red);

conf640_DF = im2double(imread('U:\Projects\01_E3_modulation\2023-01-10_thal_vhl\02_edit\04_df\MED_2023-01-10_df1_w6DVU-Conf640.tif'));
conf640_FF = im2double(imread('U:\Projects\01_E3_modulation\2023-01-10_thal_vhl\02_edit\06_640_ff\MED_2023-01-10_6401_w2DVU-Conf640.tif'));
conf640_FF_red = imsubtract(conf640_FF, conf640_DF);
conf640_FF_red_avg = mean2(conf640_FF_red);

base = 'U:\Projects\01_E3_modulation\2023-04-13_DP9mut\02_edit\02_timelapse\'
for y = 161:174
    fullpath = strcat(base,num2str(y));
    cd (fullpath);

    allfiles = [dir('*DIC*.tif'),
                dir('*EpiDAPI*.tif'),
                dir('*EpiGFP*.tif'),
                dir('*EpiRFP*.tif'),
                dir('*EpiCy5*.tif'),
                dir('*conf405*.tif'),
                dir('*Conf488*.tif'),
                dir('*Conf561*.tif'),
                dir('*Conf640*.tif')
    ]
   
    x=1;
    for file = allfiles'
        image = im2double(imread(allfiles(x).name));
        
        if contains(allfiles(x).name, 'DIC') == 1
            newimage = imsubtract(image, DIC_DF);
            newimage = imdivide(newimage, DIC_FF_red);
            newimage = immultiply(newimage, DIC_FF_red_avg);
            newimage = im2uint16(newimage);
            imagename = char(strcat(fullpath, '_ff\', replace(allfiles(x).name, '.tif', '_ff.tif')));
            imwrite(newimage, imagename);
            
        elseif contains(allfiles(x).name, 'EpiDAPI') == 1
            newimage = imsubtract(image, epiDAPI_DF);
            newimage = imdivide(newimage, epiDAPI_FF_red);
            newimage = immultiply(newimage, epiDAPI_FF_red_avg);
            newimage = im2uint16(newimage);
            imagename = char(strcat(fullpath, '_ff\', replace(allfiles(x).name, '.tif', '_ff.tif')));
            imwrite(newimage,imagename);
            
        elseif contains(allfiles(x).name, 'EpiGFP') == 1
            newimage = imsubtract(image, epiGFP_DF);
            newimage = imdivide(newimage, epiGFP_FF_red);
            newimage = immultiply(newimage, epiGFP_FF_red_avg);
            newimage = im2uint16(newimage);
            imagename = char(strcat(fullpath, '_ff\', replace(allfiles(x).name, '.tif', '_ff.tif')));
            imwrite(newimage,imagename);
                     
        elseif contains(allfiles(x).name, 'EpiRFP') == 1
            newimage = imsubtract(image, epiRFP_DF);
            newimage = imdivide(newimage, epiRFP_FF_red);
            newimage = immultiply(newimage, epiRFP_FF_red_avg);
            newimage = im2uint16(newimage);
            imagename = char(strcat(fullpath, '_ff\', replace(allfiles(x).name, '.tif', '_ff.tif')));
            imwrite(newimage,imagename);
            
        elseif contains(allfiles(x).name, 'EpiCy5') == 1
            newimage = imsubtract(image, epiCY5_DF);
            newimage = imdivide(newimage, epiCY5_FF_red);
            newimage = immultiply(newimage, epiCY5_FF_red_avg);
            newimage = im2uint16(newimage);
            imagename = char(strcat(fullpath, '_ff\', replace(allfiles(x).name, '.tif', '_ff.tif')));
            imwrite(newimage,imagename);
            
        elseif contains(allfiles(x).name, 'Conf405') == 1
            newimage = imsubtract(image, conf405_DF);
            newimage = imdivide(newimage, conf405_FF_red);
            newimage = immultiply(newimage, conf405_FF_red_avg);
            newimage = im2uint16(newimage);
            imagename = char(strcat(fullpath, '_ff\', replace(allfiles(x).name, '.tif', '_ff.tif')));
            imwrite(newimage,imagename);
            
        elseif contains(allfiles(x).name, 'Conf488') == 1
            newimage = imsubtract(image, conf488_DF);
            newimage = imdivide(newimage, conf488_FF_red);
            newimage = immultiply(newimage, conf488_FF_red_avg);
            newimage = im2uint16(newimage);
            imagename = char(strcat(fullpath, '_ff\', replace(allfiles(x).name, '.tif', '_ff.tif')));
            imwrite(newimage,imagename);
            
        elseif contains(allfiles(x).name, 'Conf561') == 1
            newimage = imsubtract(image, conf561_DF);
            newimage = imdivide(newimage, conf561_FF_red);
            newimage = immultiply(newimage, conf561_FF_red_avg);
            newimage = im2uint16(newimage);
            imagename = char(strcat(fullpath, '_ff\', replace(allfiles(x).name, '.tif', '_ff.tif')));
            imwrite(newimage,imagename);
            
        elseif contains(allfiles(x).name, 'Conf640') == 1
            newimage = imsubtract(image, conf640_DF);
            newimage = imdivide(newimage, conf640_FF_red);
            newimage = immultiply(newimage, conf640_FF_red_avg);
            newimage = im2uint16(newimage);
            imagename = char(strcat(fullpath, '_ff\', replace(allfiles(x).name, '.tif', '_ff.tif')));
            imwrite(newimage,imagename);
            
        end
        x = x+1;
    end
    disp(y)
end