 base = 'U:\Projects\01_E3_modulation\2023-04-13_DP9mut\02_edit\02_timelapse\';
for y = 1:174
    fullpath = strcat(base,num2str(y))
    cd (fullpath);

    allfiles = dir('*EpiGFP*.tif');
    fileID = fopen('matlab_output.txt','w');
    
    x = 1;
    for file = allfiles'
        imagedata = imfinfo(allfiles(x).name);
        imagedata(1).DateTime;
        fprintf(fileID, '%s, %s\r\n', allfiles(x).name, imagedata(1).DateTime);
        x = x+1;
    end
end