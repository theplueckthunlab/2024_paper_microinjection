# Set the work directory to where the file is currently located
workdirectory <- getSrcDirectory(function(x) {x})
setwd(workdirectory)

for (i in 1:174){
  # Access subfolder dependent on loop
  setwd(paste(workdirectory, "/", i, "_ff", sep=""))
  
  # allfiles_DAPI <- list.files(pattern = "EpiDAPI")
  allfiles_GFP <-  list.files(pattern = "EpiGFP")
  allfiles_RFP <-  list.files(pattern = "EpiRFP")
  allfiles_Cy5 <-  list.files(pattern = "EpiCy5")

  # add the current folder into the path for cellprofiler to get the right files
  # replace forward slash with backward slash
  # allfiles_DAPI <- paste(workdirectory, "/", i, "_ff", "/", allfiles_DAPI, sep = "")
  # allfiles_DAPI <- gsub("/", "\\\\", allfiles_DAPI)
  
  allfiles_GFP <- paste(workdirectory, "/", i, "_ff", "/", allfiles_GFP, sep = "")
  allfiles_GFP <- gsub("/", "\\\\", allfiles_GFP)
  
  allfiles_RFP <- paste(workdirectory, "/", i, "_ff", "/", allfiles_RFP, sep = "")
  allfiles_RFP <- gsub("/", "\\\\", allfiles_RFP)
  
  allfiles_Cy5 <- paste(workdirectory, "/", i, "_ff", "/", allfiles_Cy5, sep = "")
  allfiles_Cy5 <- gsub("/", "\\\\", allfiles_Cy5)
  
  #Bind the two datasets together horizontally!
  allfiles <- paste(#allfiles_DAPI,
                    allfiles_GFP,
                    allfiles_RFP,
                    allfiles_Cy5,
                    sep = ","
  )
  
  #convert to dataframe for future column name addition
  allfiles <- data.frame(allfiles)
  
  #add column name, which is needed for cellprofiler to understand the imageseries name
  names(allfiles) <- "Image_FileName_GFP,Image_FileName_RFP,Image_FileName_Cy5"
  #names(allfiles) <- "Image_FileName_DAPI,Image_FileName_GFP,Image_FileName_Cy5"
  
  #write to CSV
  write.table(allfiles, file="cellprofilerlist.csv ", eol = "\r\n", sep=",", col.names = TRUE, append= FALSE, row.names=FALSE, quote = FALSE)
}
