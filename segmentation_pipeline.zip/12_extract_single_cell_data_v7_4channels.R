#####################################################################################
# David's CellPRofiler graphing suite v3.0
#####################################################################################

library(ggplot2)
library(dplyr)
library(tidyr)
library(forcats)

#Get rid of all currently defined objects
rm(list = ls())

#Set the work directory to where the file is currently located
workdirectory <- getSrcDirectory(function(x) {x})
setwd(workdirectory)

experiment <- "2023-04-13"

analytes <- list(
  "1131_GS-eGFP" = c(2,4,6,8,9,10,11,13,14,15,16,17,18,19,20,22,23,24,25,26,28,29,31,32,34,35,36,37),
  "1192_3G61_L33A-G4S-G3-C-TMR" = c(39,40,41,42,45,46,47,49,50,51,52,53,54,56,57,58,59,60,61,62,64,65,66,67,68,69,70,71,72,73,74,76,78,80,81,82),
  "1193_3G61_I67L-G4S-G3-C-TMR" = c(85,86,87,88,91,93,96,97,100,101,102,103,104,109,111,112,115,117,119,120,123,124,125,127,128,129,130),
  "1194_3G61_Y91N-G4S-G3-C-TMR" = c(131,132,133,136,137,138,139,140,141,143,144,146,149,150,151,152,153,154,155,156,158,161,162,164,167,169,171,172,173)
)

# Initate final output table
output     <- tibble("exp.id"      = character(),  #1
                     "pos.id"      = numeric(),    #2
                     "cell.id"     = numeric(),    #3
                     "tp.id"       = numeric(),    #4
                     "tp.posix"    = numeric(),    #5
                     "tp.postinj"  = numeric(),    #6
                     "epi.405.int" = numeric(),    #7
                     "epi.488.int" = numeric(),    #8
                     "epi.561.int" = numeric(),    #9
                     "epi.640.int"  = numeric(),   #10
                     "analyte"     = character()   #11 
)

# Loop over each list of positions (over all analytes)
analytecounter <- 0
for (x in analytes){
  analytecounter <- analytecounter + 1
  
  # Loop over each position of list
  for (s in x){
  
    #Access subfolder dependent on loop
    subfolderpath <- paste(workdirectory,
                           "/",
                           s,
                           "_tr1",
                           sep=""
    )
    setwd(subfolderpath)
  

  
    ############################################
    # Timepoint management
    ############################################
  
    # read in the timepoints from the matlab output file also located in the same folder as the source file,
    # assign names to the columns and select those that contain the term "GFP"
    timepoints <- read.csv("matlab_output.csv",
                           header = FALSE
    )
    
        #Initiate results tibble and assign column names
    calculation     <- tibble("exp.id"       = character(), #1
                              "pos.id"       = numeric(),   #2
                              "cell.id"      = numeric(),   #3
                              "tp.id"        = numeric(),   #4
                              "tp.POSIXct"   = numeric(),   #5
                              "tp.postinj"   = numeric(),   #6
                              "object1.405"  = numeric(),   #7
                              "object1.488"  = numeric(),   #8
                              "object1.561"  = numeric(),   #9
                              "object1.640"  = numeric(),   #10
                              "object2.405"  = numeric(),   #11
                              "object2.488"  = numeric(),   #12
                              "object2.561"  = numeric(),   #13
                              "object2.640"  = numeric(),   #14
                              "object3.405"  = numeric(),   #15
                              "object3.488"  = numeric(),   #16
                              "object3.561"  = numeric(),   #17
                              "object3.640"  = numeric(),   #18
                              "object4.405"  = numeric(),   #19
                              "object4.488"  = numeric(),   #20
                              "object4.561"  = numeric(),   #21
                              "object4.640"  = numeric(),   #22
                              "object5.405"  = numeric(),   #23
                              "object5.488"  = numeric(),   #24
                              "object5.561"  = numeric(),   #25
                              "object5.640"  = numeric(),   #26
                              "object6.405"  = numeric(),   #27
                              "object6.488"  = numeric(),   #28
                              "object6.561"  = numeric(),   #29
                              "object6.640"  = numeric(),   #30
                              "object7.405"  = numeric(),   #31
                              "object7.488"  = numeric(),   #32
                              "object7.561"  = numeric(),   #33
                              "object7.640"  = numeric(),   #34
                              "object8.405"  = numeric(),   #35
                              "object8.488"  = numeric(),   #36
                              "object8.561"  = numeric(),   #37
                              "object8.640"  = numeric(),   #38
                              "object9.405"  = numeric(),   #39
                              "object9.488"  = numeric(),   #40
                              "object9.561"  = numeric(),   #41
                              "object9.640"  = numeric(),   #42
                              "object10.405"  = numeric(),  #43
                              "object10.488"  = numeric(),  #44
                              "object10.561"  = numeric(),  #45
                              "object10.640"  = numeric(),  #46
                              "object11.405"  = numeric(),  #47
                              "object11.488"  = numeric(),  #48
                              "object11.561"  = numeric(),  #49
                              "object11.640"  = numeric(),  #50 
                              "object12.405"  = numeric(),  #51
                              "object12.488"  = numeric(),  #52
                              "object12.561"  = numeric(),  #53
                              "object12.640"  = numeric(),  #54     
                              "object13.405"  = numeric(),  #55
                              "object13.488"  = numeric(),  #56
                              "object13.561"  = numeric(),  #57
                              "object13.640"  = numeric(),  #58     
                              "object14.405"  = numeric(),  #59
                              "object14.488"  = numeric(),  #60
                              "object14.561"  = numeric(),  #61
                              "object14.640"  = numeric(),  #62     
                              "object15.405"  = numeric(),  #63
                              "object15.488"  = numeric(),  #64
                              "object15.561"  = numeric(),  #65
                              "object15.640"  = numeric(),  #66     
                              "object16.405"  = numeric(),  #67
                              "object16.488"  = numeric(),  #68
                              "object16.561"  = numeric(),  #69
                              "object16.640"  = numeric(),  #70     
                              "object17.405"  = numeric(),  #71
                              "object17.488"  = numeric(),  #72
                              "object17.561"  = numeric(),  #73
                              "object17.640"  = numeric(),  #74     
                              "object18.405"  = numeric(),  #75
                              "object18.488"  = numeric(),  #76
                              "object18.561"  = numeric(),  #77
                              "object18.640"  = numeric(),  #78     
                              "object19.405"  = numeric(),  #79
                              "object19.488"  = numeric(),  #80
                              "object19.561"  = numeric(),  #81
                              "object19.640"  = numeric(),  #82     
                              "object20.405"  = numeric(),  #83
                              "object20.488"  = numeric(),  #84
                              "object20.561"  = numeric(),  #85
                              "object20.640"  = numeric(),  #86     
                              "object21.405"  = numeric(),  #87
                              "object21.488"  = numeric(),  #88
                              "object21.561"  = numeric(),  #89
                              "object21.640"  = numeric(),  #90     
                              "object22.405"  = numeric(),  #91
                              "object22.488"  = numeric(),  #92
                              "object22.561"  = numeric(),  #93
                              "object22.640"  = numeric(),  #94     
                              "object23.405"  = numeric(),  #95
                              "object23.488"  = numeric(),  #96
                              "object23.561"  = numeric(),  #97
                              "object23.640"  = numeric(),  #98     
                              "object24.405"  = numeric(),  #99
                              "object24.488"  = numeric(),  #100
                              "object24.561"  = numeric(),  #101
                              "object24.640"  = numeric(),  #102    
                              "object25.405"  = numeric(),  #103
                              "object25.488"  = numeric(),  #104
                              "object25.561"  = numeric(),  #105
                              "object25.640"  = numeric(),  #106    
                              "object26.405"  = numeric(),  #107
                              "object26.488"  = numeric(),  #108
                              "object26.561"  = numeric(),  #109
                              "object26.640"  = numeric(),  #110    
                              "object27.405"  = numeric(),  #111
                              "object27.488"  = numeric(),  #112
                              "object27.561"  = numeric(),  #113
                              "object27.640"  = numeric(),  #114    
                              "object28.405"  = numeric(),  #115
                              "object28.488"  = numeric(),  #116
                              "object28.561"  = numeric(),  #117
                              "object28.640"  = numeric(),  #118    
                              "object29.405"  = numeric(),  #119
                              "object29.488"  = numeric(),  #120
                              "object29.561"  = numeric(),  #121
                              "object29.640"  = numeric(),  #122    
                              "object30.405"  = numeric(),  #123
                              "object30.488"  = numeric(),  #124
                              "object30.561"  = numeric(),  #125
                              "object30.640"  = numeric(),  #126    
                              "object31.405"  = numeric(),  #127
                              "object31.488"  = numeric(),  #128
                              "object31.561"  = numeric(),  #129
                              "object31.640"  = numeric(),  #130    
                              "object32.405"  = numeric(),  #131
                              "object32.488"  = numeric(),  #132
                              "object32.561"  = numeric(),  #133
                              "object32.640"  = numeric(),  #134    
                              "object33.405"  = numeric(),  #135
                              "object33.488"  = numeric(),  #136
                              "object33.561"  = numeric(),  #137
                              "object33.640"  = numeric(),  #138    
                              "object34.405"  = numeric(),  #139
                              "object34.488"  = numeric(),  #140
                              "object34.561"  = numeric(),  #141
                              "object34.640"  = numeric(),  #142    
                              "object35.405"  = numeric(),  #143
                              "object35.488"  = numeric(),  #144
                              "object35.561"  = numeric(),  #145
                              "object35.640"  = numeric(),  #146    
                              "object36.405"  = numeric(),  #147
                              "object36.488"  = numeric(),  #148
                              "object36.561"  = numeric(),  #149
                              "object36.640"  = numeric(),  #150    
                              "object37.405"  = numeric(),  #151
                              "object37.488"  = numeric(),  #152
                              "object37.561"  = numeric(),  #153
                              "object37.640"  = numeric(),  #154    
                              "object38.405"  = numeric(),  #155
                              "object38.488"  = numeric(),  #156
                              "object38.561"  = numeric(),  #157
                              "object38.640"  = numeric(),  #158    
                              "object39.405"  = numeric(),  #159
                              "object39.488"  = numeric(),  #160
                              "object39.561"  = numeric(),  #161
                              "object39.640"  = numeric(),  #162 
                              "object40.405"  = numeric(),  #163
                              "object40.488"  = numeric(),  #164
                              "object40.561"  = numeric(),  #165
                              "object40.640"  = numeric(),  #166     
                              "object41.405"  = numeric(),  #167
                              "object41.488"  = numeric(),  #168
                              "object41.561"  = numeric(),  #169
                              "object41.640"  = numeric(),  #170     
                              "object42.405"  = numeric(),  #171
                              "object42.488"  = numeric(),  #172
                              "object42.561"  = numeric(),  #173
                              "object42.640"  = numeric(),  #174     
                              "object43.405"  = numeric(),  #175
                              "object43.488"  = numeric(),  #176
                              "object43.561"  = numeric(),  #177
                              "object43.640"  = numeric(),  #178     
                              "object44.405"  = numeric(),  #179
                              "object44.488"  = numeric(),  #180
                              "object44.561"  = numeric(),  #181
                              "object44.640"  = numeric(),  #182     
                              "object45.405"  = numeric(),  #183
                              "object45.488"  = numeric(),  #184
                              "object45.561"  = numeric(),  #185
                              "object45.640"  = numeric(),  #186     
                              "object46.405"  = numeric(),  #187
                              "object46.488"  = numeric(),  #188
                              "object46.561"  = numeric(),  #189
                              "object46.640"  = numeric(),  #190     
                              "object47.405"  = numeric(),  #191
                              "object47.488"  = numeric(),  #192
                              "object47.561"  = numeric(),  #193
                              "object47.640"  = numeric(),  #194     
                              "object48.405"  = numeric(),  #195
                              "object48.488"  = numeric(),  #196
                              "object48.561"  = numeric(),  #197
                              "object48.640"  = numeric(),  #198     
                              "object49.405"  = numeric(),  #199
                              "object49.488"  = numeric(),  #200
                              "object49.561"  = numeric(),  #201
                              "object49.640"  = numeric(),  #202     
                              "object50.405"  = numeric(),  #203
                              "object50.488"  = numeric(),  #204
                              "object50.561"  = numeric(),  #205
                              "object50.640"  = numeric(),  #206     
                              "object51.405"  = numeric(),  #207
                              "object51.488"  = numeric(),  #208
                              "object51.561"  = numeric(),  #209
                              "object51.640"  = numeric(),  #210     
                              "object52.405"  = numeric(),  #211
                              "object52.488"  = numeric(),  #212
                              "object52.561"  = numeric(),  #213
                              "object52.640"  = numeric(),  #214     
                              "object53.405"  = numeric(),  #215
                              "object53.488"  = numeric(),  #216
                              "object53.561"  = numeric(),  #217
                              "object53.640"  = numeric(),  #218     
                              "object54.405"  = numeric(),  #219
                              "object54.488"  = numeric(),  #220
                              "object54.561"  = numeric(),  #221
                              "object54.640"  = numeric(),  #222     
                              "object55.405"  = numeric(),  #223
                              "object55.488"  = numeric(),  #224
                              "object55.561"  = numeric(),  #225
                              "object55.640"  = numeric(),  #226     
                              "object56.405"  = numeric(),  #227
                              "object56.488"  = numeric(),  #228
                              "object56.561"  = numeric(),  #229
                              "object56.640"  = numeric(),  #230     
                              "object57.405"  = numeric(),  #231
                              "object57.488"  = numeric(),  #232
                              "object57.561"  = numeric(),  #233
                              "object57.640"  = numeric()   #234 
    ) %>%
      add_row(tp.id = rep(NA, length(timepoints[[1]])))
  
    names(timepoints) <- c("filename",
                           "timepoint"
    )
  
    # We will assume that all channels are taken at the same time once acquisition for the timepoint started
    # (this is OK, as all channels are recorded within <5 seconds)
  
    timepoints <- timepoints[c(grep("GFP", timepoints[,1])),]
  
    # Loop through timepointstable, check positioning on x axis and write corresponding time value in posix format into the results table
    for (i in 1:nrow(timepoints)){
    
      #Get timepoint index number from the filename
      timepointindex <- as.integer(strsplit(as.character(strsplit(as.character(timepoints[i,1]), "_t")[[1]][[3]]), "\\.")[[1]][[1]])
    
      # Write timepoint ID into finalizaton table
      calculation[timepointindex,4] <- timepointindex  
      
      #Get timepoint in POSIX format and put in calculation table at corresponding row in double format (seconds since somewhere in the 70s)
      calculation[timepointindex,5] <- as.double(as.POSIXct(timepoints[i,2],
                                                            tz ="",
                                                            format= "%Y:%m:%d%t%H:%M:%S"
                                                 )
      )
    }
  
    # Here we take into account the different injection times for the positions for the calculation of passed time since injection
    if (s >= 1 & s <= 37){
      injectiontime <- as.double(as.POSIXct("2023:04:13 17:02:30", tz="", format="%Y:%m:%d%t%H:%M:%S"))
    } else if (s >= 38 & s <= 84){
      injectiontime <- as.double(as.POSIXct("2023:04:13 17:08:30", tz="", format="%Y:%m:%d%t%H:%M:%S"))
    } else if (s >= 85 & s <= 130){
      injectiontime <- as.double(as.POSIXct("2023:04:13 17:17:00", tz="", format="%Y:%m:%d%t%H:%M:%S"))
    } else if (s >= 131 & s <= 174){
      injectiontime <- as.double(as.POSIXct("2023:04:13 17:25:30", tz="", format="%Y:%m:%d%t%H:%M:%S"))
    } 
    
    
    # Convert to absolute time differences from injection time in decimal hours, store in column three of the results table
    calculation[,6] <- (calculation[,5]-injectiontime)/3600
  
    ############################################
    # Intensity Extraction
    ############################################
  
    # Read in the cellprofiler output-containing file
    possible_files <- list.files(pattern = "*cells.csv")
    fileholder1 <- read.csv(file = possible_files[[1]], header = TRUE)
  
    # Each row (identified objects) in the extracted ROI-data is looped through, and added to the results matrix
    # Dependent on the image ID (timepoint ID) as well as on object tracking ID.
    for (r in 1:nrow(fileholder1)){
      # Extract image number where the object was identified
      imagenumber      <- fileholder1$ImageNumber[r]
      
      # Access object tracking ID
      objectnumber     <- fileholder1$TrackObjects_Label_150[r]
      
      # Offset for needing multiple columns for each object (488 and 561 nm)
      objectnumber     <- objectnumber+(3*objectnumber-3)
      
      # Increase by 3 (column offset for ImageID, Posix-time and time difference to injection time point)
      objectnumber     <- objectnumber + 6
       
      # Access integrated density, creates "Null (empty)" is not in output of cellprofiler
      density.405      <- fileholder1$Intensity_IntegratedIntensity_DAPI_bgsub[r]
      density.488      <- fileholder1$Intensity_IntegratedIntensity_GFP_bgsub[r]
      density.561      <- fileholder1$Intensity_IntegratedIntensity_RFP_bgsub[r]
      density.640      <- fileholder1$Intensity_IntegratedIntensity_Cy5_bgsub[r]
      
      if (is.null(density.405) == TRUE){
        density.405 <- 0
      }

      if (is.null(density.488) == TRUE){
        density.488 <- 0
      }

      if (is.null(density.561) == TRUE){
        density.561 <- 0
      }

      if (is.null(density.640) == TRUE){
        density.640 <- 0
      }
      
      # This block looks up the current object value for the current timepoint, extracts it and just adds the intensity.
      # This is needed if there are multiple single objects with the same tracking ID and same timepoint, which happens from time to time.
      currentvalue.405 <- as.numeric(calculation[imagenumber, objectnumber+0])
      currentvalue.488 <- as.numeric(calculation[imagenumber, objectnumber+1])
      currentvalue.561 <- as.numeric(calculation[imagenumber, objectnumber+2])
      currentvalue.640 <- as.numeric(calculation[imagenumber, objectnumber+3])
      
      # In the calculation table, empty cells cause NA values, which need to be
      # put to zero for the following calculations
      if (is.na(currentvalue.405) == TRUE){
        currentvalue.405 <- 0
      }

      if (is.na(currentvalue.488) == TRUE){
        currentvalue.488 <- 0
      }

      if (is.na(currentvalue.561) == TRUE){
        currentvalue.561 <- 0
      }

      if (is.na(currentvalue.640) == TRUE){
        currentvalue.640 <- 0
      }
      
      currentvalue.405 <- density.405+currentvalue.405
      currentvalue.488 <- density.488+currentvalue.488
      currentvalue.561 <- density.561+currentvalue.561
      currentvalue.640 <- density.640+currentvalue.640

      calculation[imagenumber, objectnumber+0] <- currentvalue.405    
      calculation[imagenumber, objectnumber+1] <- currentvalue.488
      calculation[imagenumber, objectnumber+2] <- currentvalue.561
      calculation[imagenumber, objectnumber+3] <- currentvalue.640
    }
  
    # Read in the roifile
    roifile <- read.csv("rois.csv", header=FALSE)

    # Check the ROI file and then, depending on how many cells are mentioned there, create an entry in the final resultsfile
    for (w in 1:nrow(roifile)){
      tempoutput <- tibble("exp.id"      = character(),  #1
                           "pos.id"      = numeric(),    #2
                           "cell.id"     = numeric(),    #3
                           "tp.id"       = numeric(),    #4
                           "tp.posix"    = numeric(),    #5
                           "tp.postinj"  = numeric(),    #6
                           "epi.405.int" = numeric(),    #7
                           "epi.488.int" = numeric(),    #8
                           "epi.561.int" = numeric(),    #9
                           "epi.640.int"  = numeric(),   #10
                           "analyte"     = character()   #11 
      )
      
      # Total length of images in calculation file
      datasetlength <- length(calculation[[1]])
      
      # Extract all numbers of ROI file into vector
      selectcolumns <- as.numeric(roifile[w,])
      
      # if one of the ROI numbers is NA, for example if a colon was put in wrongly
      # they are excluded
      selectcolumns <- selectcolumns[!is.na(selectcolumns)]
      
      # another failure problem in roi 
      dropzeroes <- which(selectcolumns == 0)
      
      # if zeroes are found DO 
      if(length(dropzeroes) != 0) {
        selectcolumns <- selectcolumns[-which(selectcolumns == 0)]
      }
      
      selectcolumns <- selectcolumns+(3*selectcolumns-3)+6
      
      tempoutput[c(1:datasetlength), 1]  <- rep(experiment, datasetlength)
      tempoutput[c(1:datasetlength), 2]  <- rep(s, datasetlength)
      tempoutput[c(1:datasetlength), 3]  <- rep(w, datasetlength)
      tempoutput[c(1:datasetlength), 4]  <- calculation$tp.id
      tempoutput[c(1:datasetlength), 5]  <- calculation$tp.POSIXct
      tempoutput[c(1:datasetlength), 6]  <- calculation$tp.postinj
      tempoutput[c(1:datasetlength), 7]  <- calculation %>% select(selectcolumns)   %>% rowSums(na.rm = TRUE)
      tempoutput[c(1:datasetlength), 8]  <- calculation %>% select(selectcolumns+1) %>% rowSums(na.rm = TRUE)
      tempoutput[c(1:datasetlength), 9]  <- calculation %>% select(selectcolumns+2) %>% rowSums(na.rm = TRUE)
      tempoutput[c(1:datasetlength), 10] <- calculation %>% select(selectcolumns+3) %>% rowSums(na.rm = TRUE)
      tempoutput[c(1:datasetlength), 11] <- rep(names(analytes)[analytecounter], datasetlength)
      
      output <- rbind(output, tempoutput)
    }
  }
}

# In the end, replace all zero values with NA, so they're correctly removed from the downstream plots.
output <- as.data.frame(output)
output[output == 0] <- NA
output <- as_tibble(output)

output <- output %>% 
  dplyr::filter(tp.postinj <= 12)

# Write this into an output file, that's the final result
setwd(workdirectory)
write.csv(output, file = paste(experiment, "_output1.csv", sep = ""), row.names = FALSE)
